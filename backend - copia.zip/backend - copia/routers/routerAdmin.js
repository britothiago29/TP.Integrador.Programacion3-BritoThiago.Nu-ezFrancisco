const express = require("express");
const router = express.Router();
const adminController = require("../controllers/adminController");
const isAdmin = require("../middlewares/isAdmin");

// login
router.get("/login", adminController.login);
router.post("/login", adminController.processLogin);

// dashboard
router.get("/", isAdmin, adminController.dashboard);

// alta producto
router.get("/productos/crear", isAdmin, adminController.createForm);
router.post("/productos/crear", isAdmin, adminController.create);

// editar producto
router.get("/productos/editar/:id", isAdmin, adminController.editForm);
router.post("/productos/editar/:id", isAdmin, adminController.update);

// activar
router.post("/productos/activar/:id", isAdmin, adminController.activate);

// desactivar
router.post("/productos/desactivar/:id", isAdmin, adminController.deactivate);

module.exports = router;
